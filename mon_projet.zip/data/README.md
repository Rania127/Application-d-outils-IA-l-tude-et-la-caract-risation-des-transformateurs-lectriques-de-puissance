# Donnees du projet

## Fichiers de donnees:
- `Dataset_sine.json` : Dataset de signaux sinusoidaux
- `meas_FNO.csv` : Donnees de mesures reelles
- `pred_FNO.csv` : Predictions generees par le modele
- `test_dataset.pt` : Dataset de test au format PyTorch
