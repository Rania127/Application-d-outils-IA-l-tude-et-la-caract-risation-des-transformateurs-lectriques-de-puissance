# Modeles entraines

## Fichiers:
- `Model_fno_magnetic.sd` : Modele FNO pour analyse magnetique

Ce modele peut etre charge avec PyTorch pour faire des predictions.
